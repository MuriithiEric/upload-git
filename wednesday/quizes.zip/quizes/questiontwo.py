Celsius = int(input("Enter a temperature in Celsius: ")) #input a number in celcius to be converted to celcius

Fahrenheit = 9.0/5.0 * Celsius + 32 #formula to convert fahrenheit to celcius

print ("The temperatue in Fahrenheit is", Fahrenheit) #prints out the value of celcius in **fahrenheit

Fahrenheit = int(input("Enter a temperature in Fahrenheit: ")) #input a number in fahrenheit to be converted to celcius

Celcius = (Fahrenheit - 32) * 5 / 9 #formula to convert celcius to fahrenheit

print("The reverse calculation, the temperature in celcius is", Celcius) #prints out the value of fahrenheit in **celcius