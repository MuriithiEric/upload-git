grades = int(input("Please enter your score: "))

if grades >= 70 and grades < 100:
    print("Congrats You scored an A!")

elif grades >= 60 and grades <= 69:
    print("Good job! You scored a B!")

elif grades >= 50 and grades <= 59:
    print("You scored a C!")      

elif grades >= 40 and grades <= 49:
    print("You scored a D")

elif grades >=0 and grades <=39:
    print("You scored an E")    


